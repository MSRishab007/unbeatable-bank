"""A FastAPI dependency that hands out pooled database connections without deadlocking.

The plain way, a sync generator dependency around `pool.connection()`, deadlocks under
load. FastAPI runs a sync dependency, and every sync endpoint, on a worker thread
(40 by default). When more requests arrive than the pool has connections, the waiting
requests take every worker thread, each blocked in `pool.getconn()`. The requests that
do hold a connection then need a worker thread to run their endpoint and give the
connection back, and there is none: nothing moves until the pool's timeout fires and
every waiter fails. (Seen in the GKE load test: identity at 3% CPU, "couldn't get a
connection after 30 sec", the health check starved, the pod restarted in a loop.)

Here a request first waits for one of the pool's slots on the event loop, which costs no
thread, and only then takes a thread to get the connection, which is free by then.
Worker threads are only used by requests that can make progress. A request that waits
longer than `wait_seconds` gets 503 rather than hanging.
"""

from __future__ import annotations

import asyncio
from typing import Callable

from psycopg_pool import ConnectionPool

from fastapi import HTTPException
from fastapi.concurrency import run_in_threadpool

_gates: dict[tuple[int, int], asyncio.Semaphore] = {}


def _gate(pool) -> asyncio.Semaphore:
    key = (id(pool), id(asyncio.get_running_loop()))    # one per pool and event loop (tests make several)
    gate = _gates.get(key)
    if gate is None:
        gate = _gates[key] = asyncio.Semaphore(pool.max_size)
    return gate


def connection_dependency(get_pool: Callable, wait_seconds: float = 10.0):
    """`get_conn = connection_dependency(lambda: _state["pool"])`, used as Depends(get_conn)."""

    async def get_conn():
        pool = get_pool()
        gate = _gate(pool)
        try:
            await asyncio.wait_for(gate.acquire(), wait_seconds)
        except TimeoutError:
            raise HTTPException(status_code=503, detail="busy; try again",
                                headers={"Retry-After": "1"}) from None
        try:
            conn = await run_in_threadpool(pool.getconn)
            try:
                yield conn
            finally:
                await run_in_threadpool(pool.putconn, conn)
        finally:
            gate.release()

    return get_conn


def readiness(get_pool: Callable):
    """`app.get("/readyz")(readiness(lambda: _state["pool"]))`: ready while the pool is open.

    It doesn't run a query through get_conn: under load every connection is busy, so a
    probe would queue behind the requests, time out, and take a pod that is working (just
    busy) out of the Service, which sends its share of the traffic to the others and makes
    things worse. A pod whose database is really gone fails its requests with 503 anyway.
    """

    async def readyz():
        try:
            pool = get_pool()
        except Exception:  # noqa: BLE001 - not started yet
            pool = None
        if pool is None or pool.closed:
            raise HTTPException(status_code=503, detail="database pool not open")
        return {"status": "ready"}

    return readyz


def pool_options(**extra) -> dict:
    """Settings every service's ConnectionPool uses, so a database restart cannot strand it.

    After Cloud SQL restarts (maintenance, or "terminating connection due to administrator
    command"), connections already in the pool can be half-dead: the socket looks open but
    no reply ever comes, and a query on it hangs until the caller's deadline. So:
      check          the pool tests each connection before lending it and replaces a dead one
      keepalives     TCP keepalives notice a silent peer within about a minute
      tcp_user_timeout  a write that is not acknowledged in 15 s fails fast
      max_idle / max_lifetime  connections are recycled regularly anyway
    """
    kwargs = {"autocommit": True, "keepalives": 1, "keepalives_idle": 30, "keepalives_interval": 10,
              "keepalives_count": 3, "tcp_user_timeout": 15000, **extra}
    return {"kwargs": kwargs, "check": ConnectionPool.check_connection,
            "max_idle": 300.0, "max_lifetime": 1800.0}
