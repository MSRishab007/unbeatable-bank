"""Account service business logic.

Cross-service ordering is chosen so that a failure always leaves the system
in the SAFE state (money blocked rather than wrongly allowed):
  - open:     ledger account created first (blocked if KYC pending), then the
              account row. An orphan ledger row with zero balance is harmless.
  - freeze:   ledger blocked first, then status updated.
  - unfreeze: status updated first, then ledger unblocked.
"""

from __future__ import annotations

import hashlib
import logging
import re
import json
from datetime import date, datetime, timedelta, timezone
from typing import Any
from uuid import UUID, uuid4

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from .ledger_client import LedgerClient
from .numbers import PAN_RE, hash_pan, is_valid_account_number, make_account_number

MAX_HOLDERS = 4
BENEFICIARY_COOLING = timedelta(hours=24)
LIMIT_RAISE_DELAY = timedelta(hours=24)
MAX_NOMINEES = 4
NOMINEE_RELATIONS = ("SPOUSE", "CHILD", "PARENT", "SIBLING", "OTHER")

log = logging.getLogger(__name__)


class AccountError(Exception):
    code = "ACCOUNT_ERROR"
    http_status = 400

    def __init__(self, message: str, **details: Any) -> None:
        super().__init__(message)
        self.details = details


class NotFound(AccountError):
    code = "NOT_FOUND"
    http_status = 404


class Conflict(AccountError):
    code = "CONFLICT"
    http_status = 409


class Forbidden(AccountError):
    code = "FORBIDDEN"
    http_status = 403


def _cur(conn: psycopg.Connection) -> psycopg.Cursor:
    return conn.cursor(row_factory=dict_row)


# ------------------------------------------------------------------- event chain


def _event_hash(prev_hash: str | None, account_id: UUID, event_type: str, payload: dict, actor: str) -> str:
    body = json.dumps(
        {"prev": prev_hash, "account": str(account_id), "type": event_type, "payload": payload, "actor": actor},
        sort_keys=True, default=str,
    )
    return hashlib.sha256(body.encode()).hexdigest()


def _record_event(cur: psycopg.Cursor, account_id: UUID, event_type: str, payload: dict, actor: str) -> None:
    """Caller must hold the account row lock, so the chain can't fork."""
    cur.execute(
        "SELECT hash FROM account.account_events WHERE account_id = %s ORDER BY event_id DESC LIMIT 1",
        (account_id,),
    )
    prev = cur.fetchone()
    prev_hash = prev["hash"] if prev else None
    h = _event_hash(prev_hash, account_id, event_type, payload, actor)
    cur.execute(
        """
        INSERT INTO account.account_events (account_id, event_type, payload, actor, prev_hash, hash)
        VALUES (%s, %s, %s, %s, %s, %s)
        """,
        (account_id, event_type, Jsonb(payload), actor, prev_hash, h),
    )
    cur.execute(
        "INSERT INTO account.outbox (topic, event_key, event_type, payload) VALUES (%s, %s, %s, %s)",
        ("account.events", str(account_id), event_type,
         Jsonb({"account_id": str(account_id), "actor": actor, **payload})),
    )


def verify_event_chain(conn: psycopg.Connection, account_id: UUID) -> bool:
    with _cur(conn) as cur:
        cur.execute(
            "SELECT * FROM account.account_events WHERE account_id = %s ORDER BY event_id", (account_id,)
        )
        prev_hash = None
        for e in cur.fetchall():
            expected = _event_hash(prev_hash, account_id, e["event_type"], e["payload"], e["actor"])
            if e["prev_hash"] != prev_hash or e["hash"] != expected:
                return False
            prev_hash = e["hash"]
    return True


# ------------------------------------------------------------------- customers


def create_customer(
    conn: psycopg.Connection, *, full_name: str, date_of_birth: date, phone: str, email: str,
    pan: str | None = None, customer_id: UUID | None = None,
) -> dict:
    """Pass customer_id (Identity does) to make the call idempotent."""
    if customer_id is not None:
        try:
            return get_customer(conn, customer_id)
        except NotFound:
            pass
    pan_hash = pan_last4 = None
    if pan:
        pan = pan.strip().upper()
        if not PAN_RE.match(pan):
            raise AccountError("invalid PAN format")
        pan_hash, pan_last4 = hash_pan(pan), pan[-5:]
    try:
        with conn.transaction(), _cur(conn) as cur:
            cur.execute(
                """
                INSERT INTO account.customers
                    (customer_id, full_name, date_of_birth, phone, email, pan_hash, pan_last4)
                VALUES (COALESCE(%s, gen_random_uuid()), %s, %s, %s, %s, %s, %s) RETURNING *
                """,
                (customer_id, full_name.strip(), date_of_birth, phone, email.strip().lower(), pan_hash,
                 pan_last4),
            )
            return _public_customer(cur.fetchone())
    except psycopg.errors.UniqueViolation as e:
        field = {"customers_phone_key": "phone", "customers_email_key": "email",
                 "customers_pan_hash_key": "pan"}.get(e.diag.constraint_name, "unknown")
        raise Conflict(f"a customer with this {field} already exists", field=field) from e
    except psycopg.errors.CheckViolation as e:
        raise AccountError("invalid customer details", constraint=e.diag.constraint_name) from e


def _public_customer(row: dict) -> dict:
    row = dict(row)
    row.pop("pan_hash", None)
    return row


def get_customer(conn: psycopg.Connection, customer_id: UUID) -> dict:
    with _cur(conn) as cur:
        cur.execute("SELECT * FROM account.customers WHERE customer_id = %s", (customer_id,))
        row = cur.fetchone()
    if row is None:
        raise NotFound("customer not found")
    return _public_customer(row)


def search_customers(conn: psycopg.Connection, query: str, kyc_status: str | None = None, limit: int = 20) -> list[dict]:
    """Staff lookup. Exact match on CIF, email, phone or account number; otherwise a name search.

    An empty query lists the newest customers (optionally only one KYC status).
    """
    q = query.strip()
    where, params = [], []
    if q:
        where.append(
            "(c.cif_number = upper(%s) OR c.email = lower(%s) OR c.phone = %s OR c.customer_id::text = lower(%s) "
            "OR c.full_name ILIKE %s OR EXISTS (SELECT 1 FROM account.account_holders h "
            "JOIN account.accounts a ON a.account_id = h.account_id "
            "WHERE h.customer_id = c.customer_id AND a.account_number = %s))")
        like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        params += [q, q, q, q, like, q]
    if kyc_status:
        where.append("c.kyc_status = %s")
        params.append(kyc_status)
    sql = "SELECT c.* FROM account.customers c"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY c.created_at DESC LIMIT %s"
    with _cur(conn) as cur:
        cur.execute(sql, (*params, max(1, min(limit, 50))))
        return [_public_customer(r) for r in cur.fetchall()]


def verify_kyc(conn: psycopg.Connection, ledger: LedgerClient, customer_id: UUID, actor: str) -> dict:
    """Mark KYC verified and activate accounts where every holder is now verified."""
    with conn.transaction(), _cur(conn) as cur:
        cur.execute(
            "UPDATE account.customers SET kyc_status = 'VERIFIED' WHERE customer_id = %s RETURNING *",
            (customer_id,),
        )
        customer = cur.fetchone()
        if customer is None:
            raise NotFound("customer not found")
        cur.execute(
            """
            SELECT a.account_id FROM account.accounts a
            JOIN account.account_holders h ON h.account_id = a.account_id AND h.removed_at IS NULL
            WHERE h.customer_id = %s AND a.status = 'PENDING_KYC'
              AND NOT EXISTS (
                  SELECT 1 FROM account.account_holders h2
                  JOIN account.customers c ON c.customer_id = h2.customer_id
                  WHERE h2.account_id = a.account_id AND h2.removed_at IS NULL
                    AND c.kyc_status <> 'VERIFIED')
            ORDER BY a.account_id
            FOR UPDATE OF a
            """,
            (customer_id,),
        )
        activated = [r["account_id"] for r in cur.fetchall()]
        for account_id in activated:
            cur.execute("UPDATE account.accounts SET status = 'ACTIVE' WHERE account_id = %s", (account_id,))
            _record_event(cur, account_id, "ACCOUNT_ACTIVATED", {"reason": "kyc_verified"}, actor)
    for account_id in activated:  # unblock after commit (safe order)
        ledger.set_status(account_id, "OPEN")
    return {**_public_customer(customer), "activated_accounts": [str(a) for a in activated]}


# ------------------------------------------------------------------- accounts


def open_account(
    conn: psycopg.Connection,
    ledger: LedgerClient,
    *,
    product_type: str,
    holder_ids: list[UUID],
    operating_mode: str | None = None,
    overdraft_limit: int = 0,
    daily_limit: int | None = None,
    per_txn_limit: int | None = None,
    nickname: str | None = None,
    account_id: UUID | None = None,
    actor: str,
) -> dict:
    """holder_ids[0] becomes the PRIMARY holder.

    Pass account_id to make the call idempotent: opening the same id twice
    returns the existing account."""
    if account_id is not None:
        try:
            return get_account(conn, account_id)
        except NotFound:
            pass
    if not holder_ids or len(holder_ids) > MAX_HOLDERS or len(set(holder_ids)) != len(holder_ids):
        raise AccountError(f"an account needs 1 to {MAX_HOLDERS} distinct holders")
    mode = operating_mode or ("SINGLE" if len(holder_ids) == 1 else "EITHER_OR_SURVIVOR")
    if (mode == "SINGLE") != (len(holder_ids) == 1):
        raise AccountError("SINGLE mode needs exactly one holder; joint modes need two or more")
    if mode == "JOINTLY":
        raise AccountError("JOINTLY operating mode is not supported yet")
    if overdraft_limit and product_type != "CURRENT":
        raise AccountError("overdraft is only available on CURRENT accounts")

    with _cur(conn) as cur:
        cur.execute(
            "SELECT customer_id, status, kyc_status FROM account.customers WHERE customer_id = ANY(%s)",
            (holder_ids,),
        )
        customers = {r["customer_id"]: r for r in cur.fetchall()}
    missing = [str(h) for h in holder_ids if h not in customers]
    if missing:
        raise NotFound("customer not found", customer_ids=missing)
    if any(c["status"] != "ACTIVE" for c in customers.values()):
        raise Forbidden("all holders must be active customers")
    all_verified = all(c["kyc_status"] == "VERIFIED" for c in customers.values())
    status = "ACTIVE" if all_verified else "PENDING_KYC"

    account_id = account_id or uuid4()
    ledger.open_account(account_id, product_type, overdraft_limit)
    if status != "ACTIVE":
        ledger.set_status(account_id, "DEBIT_BLOCKED")

    with conn.transaction(), _cur(conn) as cur:
        cur.execute("SELECT nextval('account.account_no_seq') AS n")
        number = make_account_number(cur.fetchone()["n"])
        cur.execute(
            """
            INSERT INTO account.accounts
                (account_id, account_number, product_type, operating_mode, status, overdraft_limit,
                 daily_limit, per_txn_limit, nickname)
            VALUES (%s, %s, %s, %s, %s, %s, COALESCE(%s, 10000000), COALESCE(%s, 5000000), %s)
            """,
            (account_id, number, product_type, mode, status, overdraft_limit,
             daily_limit, per_txn_limit, nickname),
        )
        for i, customer_id in enumerate(holder_ids):
            cur.execute(
                "INSERT INTO account.account_holders (account_id, customer_id, role) VALUES (%s, %s, %s)",
                (account_id, customer_id, "PRIMARY" if i == 0 else "JOINT"),
            )
        cur.execute("SELECT 1 FROM account.accounts WHERE account_id = %s FOR UPDATE", (account_id,))
        _record_event(cur, account_id, "ACCOUNT_OPENED", {
            "account_number": number, "product_type": product_type, "operating_mode": mode,
            "holders": [str(h) for h in holder_ids], "status": status,
        }, actor)
    return get_account(conn, account_id)


def _apply_due_limits(conn: psycopg.Connection, account_id: UUID) -> None:
    """A raised limit whose waiting time is over becomes the limit."""
    with conn.transaction(), _cur(conn) as cur:
        cur.execute(
            """
            UPDATE account.accounts
            SET daily_limit = COALESCE(pending_daily_limit, daily_limit),
                per_txn_limit = COALESCE(pending_per_txn_limit, per_txn_limit),
                pending_daily_limit = NULL, pending_per_txn_limit = NULL, pending_limits_at = NULL
            WHERE account_id = %s AND pending_limits_at <= now()
            RETURNING daily_limit, per_txn_limit
            """,
            (account_id,),
        )
        row = cur.fetchone()
        if row:
            _record_event(cur, account_id, "LIMITS_RAISED", dict(row), "system:account")


def get_account(conn: psycopg.Connection, account_id: UUID) -> dict:
    _apply_due_limits(conn, account_id)
    with _cur(conn) as cur:
        cur.execute("SELECT * FROM account.accounts WHERE account_id = %s", (account_id,))
        account = cur.fetchone()
        if account is None:
            raise NotFound("account not found")
        cur.execute(
            """
            SELECT h.customer_id, h.role, h.added_at, c.full_name, c.cif_number
            FROM account.account_holders h JOIN account.customers c USING (customer_id)
            WHERE h.account_id = %s AND h.removed_at IS NULL
            ORDER BY h.role DESC, h.added_at
            """,
            (account_id,),
        )
        account["holders"] = cur.fetchall()
    return account


def list_customer_accounts(conn: psycopg.Connection, customer_id: UUID) -> list[dict]:
    with _cur(conn) as cur:
        cur.execute(
            """
            SELECT a.*, h.role AS my_role
            FROM account.accounts a JOIN account.account_holders h USING (account_id)
            WHERE h.customer_id = %s AND h.removed_at IS NULL AND a.status <> 'CLOSED'
            ORDER BY a.opened_at
            """,
            (customer_id,),
        )
        return cur.fetchall()


def _receivable(status: str, freeze_reason: str | None) -> bool:
    """A frozen account can still receive money (its owner may be a fraud victim, or have
    blocked everything themselves), except a mule: an account the stream job caught
    collecting money from many senders. Paying it more would only feed the scam."""
    if status in ("ACTIVE", "DORMANT"):
        return True
    return status == "FROZEN" and "MULE_FAN_IN" not in (freeze_reason or "")


def lookup_by_number(conn: psycopg.Connection, account_number: str) -> dict:
    """Payee name confirmation before paying: the holder's full registered name, as payment
    apps show it. The gateway rate-limits these lookups so names can't be harvested."""
    if not is_valid_account_number(account_number):
        raise AccountError("invalid account number (check digit failed)")
    with _cur(conn) as cur:
        cur.execute(
            """
            SELECT a.account_id, a.account_number, a.status, a.freeze_reason, c.full_name
            FROM account.accounts a
            JOIN account.account_holders h ON h.account_id = a.account_id
                 AND h.role = 'PRIMARY' AND h.removed_at IS NULL
            JOIN account.customers c ON c.customer_id = h.customer_id
            WHERE a.account_number = %s
            """,
            (account_number,),
        )
        row = cur.fetchone()
    if row is None or row["status"] == "CLOSED":
        raise NotFound("account not found")
    return {"account_id": row["account_id"], "account_number": row["account_number"],
            "display_name": row["full_name"], "kind": "ACCOUNT_NUMBER",
            "can_receive": _receivable(row["status"], row["freeze_reason"])}


def normalise_mobile(ref: str) -> str | None:
    """'+91 98765 43210', '09876543210' or '9876543210' -> '+919876543210'; anything else -> None."""
    digits = re.sub(r"[\s-]", "", ref)
    digits = digits[3:] if digits.startswith("+91") else digits[1:] if len(digits) == 11 and digits[0] == "0" else digits
    return f"+91{digits}" if re.fullmatch(r"[6-9]\d{9}", digits) else None


def resolve_mobile(conn: psycopg.Connection, mobile: str) -> dict:
    """The account a customer receives on by mobile number, if they have turned it on."""
    phone = normalise_mobile(mobile)
    if phone is None:
        raise AccountError("not a valid Indian mobile number")
    with _cur(conn) as cur:
        cur.execute(
            """
            SELECT a.account_number
            FROM account.customers c
            JOIN account.account_holders h ON h.customer_id = c.customer_id
                 AND h.role = 'PRIMARY' AND h.removed_at IS NULL
            JOIN account.accounts a ON a.account_id = h.account_id
            WHERE c.phone = %s AND c.pay_by_mobile AND a.status IN ('ACTIVE', 'DORMANT')
            ORDER BY (a.account_id = c.receiving_account_id) DESC, a.opened_at, a.account_number
            LIMIT 1
            """,
            (phone,),
        )
        row = cur.fetchone()
    if row is None:   # unknown number, not opted in, or no account that can receive: one answer for all
        raise NotFound("no one receives payments on this mobile number")
    return {**lookup_by_number(conn, row["account_number"]), "kind": "MOBILE"}


def lookup_payee(conn: psycopg.Connection, ref: str) -> dict:
    """One box for every way to name a payee: pay ID, mobile number or account number."""
    ref = ref.strip()
    if "@" in ref:
        return resolve_alias(conn, ref)
    if normalise_mobile(ref) and not re.fullmatch(r"\d{12}", ref):
        return resolve_mobile(conn, ref)
    return lookup_by_number(conn, re.sub(r"\s", "", ref))


def pay_by_mobile(conn: psycopg.Connection, customer_id: UUID) -> dict:
    with _cur(conn) as cur:
        cur.execute("SELECT phone, pay_by_mobile, receiving_account_id FROM account.customers "
                    "WHERE customer_id = %s", (customer_id,))
        row = cur.fetchone()
    if row is None:
        raise NotFound("customer not found")
    return {"enabled": row["pay_by_mobile"], "mobile": row["phone"],
            "receiving_account_id": row["receiving_account_id"]}


def set_pay_by_mobile(conn: psycopg.Connection, customer_id: UUID, *, enabled: bool,
                      receiving_account_id: UUID | None, actor: str) -> dict:
    with conn.transaction(), _cur(conn) as cur:
        if receiving_account_id is not None:
            cur.execute(
                "SELECT 1 FROM account.account_holders h JOIN account.accounts a USING (account_id) "
                "WHERE h.account_id = %s AND h.customer_id = %s AND h.role = 'PRIMARY' "
                "AND h.removed_at IS NULL AND a.status <> 'CLOSED'", (receiving_account_id, customer_id))
            if cur.fetchone() is None:
                raise AccountError("you can only receive on an open account that you hold")
        cur.execute(
            "UPDATE account.customers SET pay_by_mobile = %s, receiving_account_id = %s "
            "WHERE customer_id = %s RETURNING 1", (enabled, receiving_account_id, customer_id))
        if cur.fetchone() is None:
            raise NotFound("customer not found")
        log.info("customer %s turned pay by mobile %s (by %s)", customer_id, "on" if enabled else "off", actor)
    return pay_by_mobile(conn, customer_id)


def mask_name(full_name: str) -> str:
    """'Riya Sharma' -> 'Riya S*****'"""
    parts = full_name.split()
    return " ".join([parts[0]] + [p[0] + "*" * (len(p) - 1) for p in parts[1:]])


def authorize(conn: psycopg.Connection, account_id: UUID, customer_id: UUID, *, touch: bool = False) -> dict:
    """The single check every service uses: may this customer debit this account?

    idle_days is how long the account had been unused (dormant-account fraud signal).
    With touch=True an allowed check also records the activity."""
    due = conn.execute("SELECT pending_limits_at <= now() FROM account.accounts WHERE account_id = %s",
                       (account_id,)).fetchone()
    if due and due[0]:
        _apply_due_limits(conn, account_id)
    with _cur(conn) as cur:
        cur.execute(
            """
            SELECT a.account_id, a.account_number, a.product_type, a.status AS account_status,
                   a.operating_mode, a.daily_limit, a.per_txn_limit, a.overdraft_limit,
                   GREATEST(0, EXTRACT(DAY FROM now() - a.last_activity_at))::int AS idle_days,
                   h.role, c.status AS customer_status, c.daily_transfer_limit
            FROM account.accounts a
            JOIN account.account_holders h ON h.account_id = a.account_id AND h.removed_at IS NULL
            JOIN account.customers c ON c.customer_id = h.customer_id
            WHERE a.account_id = %s AND h.customer_id = %s
            """,
            (account_id, customer_id),
        )
        row = cur.fetchone()
    if row is None:
        return {"allowed": False, "reason": "NOT_A_HOLDER", "is_holder": False}
    reason = None
    if row["customer_status"] != "ACTIVE":
        reason = "CUSTOMER_" + row["customer_status"]
    elif row["account_status"] != "ACTIVE":
        reason = "ACCOUNT_" + row["account_status"]
    elif row["product_type"] in ("FD", "RD"):
        reason = "DEPOSIT_ACCOUNT_NOT_DEBITABLE"  # only the Deposits service moves FD/RD money
    elif row["operating_mode"] == "JOINTLY":
        reason = "NEEDS_ALL_HOLDERS"
    if touch and reason is None:
        conn.execute("UPDATE account.accounts SET last_activity_at = now() WHERE account_id = %s", (account_id,))
    return {"allowed": reason is None, "reason": reason, "is_holder": True, **row}


def precheck_payment(conn: psycopg.Connection, *, customer_id: UUID, from_account_id: UUID,
                     payee_ref: str) -> dict:
    """Everything Transaction Intake needs from this service, in one call:
    may the customer debit the account, who is the payee, and is the payee trusted
    (the customer's own account, or a saved payee past its cooling period)."""
    auth = authorize(conn, from_account_id, customer_id, touch=True)
    out: dict = {"auth": auth, "payee": None, "payee_error": None, "payee_trusted": False, "payee_own": False}
    if not auth["allowed"]:
        return out
    try:
        payee = lookup_payee(conn, payee_ref)
    except NotFound:
        out["payee_error"] = "PAYEE_NOT_FOUND"
        return out
    except AccountError:
        out["payee_error"] = "INVALID_PAYEE"
        return out
    out["payee"] = payee
    with _cur(conn) as cur:
        cur.execute(
            """
            SELECT EXISTS (SELECT 1 FROM account.account_holders
                           WHERE account_id = %(payee)s AND customer_id = %(cust)s AND removed_at IS NULL) AS own,
                   EXISTS (SELECT 1 FROM account.beneficiaries
                           WHERE customer_id = %(cust)s AND payee_account_number = %(number)s
                             AND removed_at IS NULL AND cooling_until <= now()) AS saved
            """,
            {"payee": payee["account_id"], "cust": customer_id, "number": payee["account_number"]},
        )
        row = cur.fetchone()
        # A transfer between the customer's own accounts is always trusted and, in Intake,
        # does not use up the daily limits. Intake also trusts a payee 24 h after the first
        # completed payment to them, which it can see in its own records.
        out["payee_own"] = row["own"]
        out["payee_trusted"] = row["own"] or row["saved"]
    return out


def update_limits(conn: psycopg.Connection, account_id: UUID, *, daily_limit: int | None,
                  per_txn_limit: int | None, actor: str) -> dict:
    """Customers set their own limits, up to the bank's ceiling.

    Lowering a limit takes effect at once. Raising one waits LIMIT_RAISE_DELAY (a fresh
    request replaces anything still waiting), so a takeover can't raise and drain at once."""
    ceiling = 50_000_000  # Rs 5,00,000
    for value in (daily_limit, per_txn_limit):
        if value is not None and not 0 < value <= ceiling:
            raise AccountError("limit must be between 1 paisa and Rs 5,00,000")
    _apply_due_limits(conn, account_id)
    try:
        with conn.transaction(), _cur(conn) as cur:
            cur.execute("SELECT * FROM account.accounts WHERE account_id = %s FOR UPDATE", (account_id,))
            row = cur.fetchone()
            if row is None:
                raise NotFound("account not found")
            now_values = {"daily_limit": row["daily_limit"], "per_txn_limit": row["per_txn_limit"]}
            pending = {"daily_limit": row["pending_daily_limit"], "per_txn_limit": row["pending_per_txn_limit"]}
            applied, waiting = {}, {}
            for name, value in (("daily_limit", daily_limit), ("per_txn_limit", per_txn_limit)):
                if value is None:
                    continue
                pending[name] = None                       # a new request replaces what was waiting
                if value <= now_values[name]:
                    now_values[name] = applied[name] = value
                else:
                    pending[name] = waiting[name] = value
            final_daily = pending["daily_limit"] or now_values["daily_limit"]
            final_txn = pending["per_txn_limit"] or now_values["per_txn_limit"]
            if final_txn > final_daily:
                raise AccountError("per-transaction limit cannot exceed the daily limit")
            effective_at = (datetime.now(timezone.utc) + LIMIT_RAISE_DELAY
                            if pending["daily_limit"] or pending["per_txn_limit"] else None)
            if not waiting and (pending["daily_limit"] or pending["per_txn_limit"]):
                effective_at = row["pending_limits_at"]   # untouched raise keeps its original time
            cur.execute(
                """
                UPDATE account.accounts
                SET daily_limit = %s, per_txn_limit = %s,
                    pending_daily_limit = %s, pending_per_txn_limit = %s, pending_limits_at = %s
                WHERE account_id = %s
                """,
                (now_values["daily_limit"], now_values["per_txn_limit"], pending["daily_limit"],
                 pending["per_txn_limit"], effective_at, account_id),
            )
            _record_event(cur, account_id, "LIMITS_CHANGED", {
                "applied": applied, "waiting": waiting,
                "effective_at": effective_at.isoformat() if waiting and effective_at else None,
                # kept for older readers of the event log
                "daily_limit": daily_limit, "per_txn_limit": per_txn_limit}, actor)
    except psycopg.errors.CheckViolation as e:
        raise AccountError("per-transaction limit cannot exceed the daily limit") from e
    return get_account(conn, account_id)


def list_events(conn: psycopg.Connection, account_id: UUID, limit: int = 100) -> list[dict]:
    with _cur(conn) as cur:
        cur.execute(
            "SELECT event_id, event_type, payload, actor, created_at FROM account.account_events "
            "WHERE account_id = %s ORDER BY event_id DESC LIMIT %s",
            (account_id, min(limit, 500)),
        )
        return cur.fetchall()


def add_holder(conn: psycopg.Connection, account_id: UUID, customer_id: UUID, actor: str) -> dict:
    with conn.transaction(), _cur(conn) as cur:
        cur.execute("SELECT * FROM account.accounts WHERE account_id = %s FOR UPDATE", (account_id,))
        account = cur.fetchone()
        if account is None:
            raise NotFound("account not found")
        if account["status"] in ("CLOSED", "FROZEN"):
            raise Conflict(f"cannot add holders to a {account['status'].lower()} account")
        cur.execute("SELECT status FROM account.customers WHERE customer_id = %s", (customer_id,))
        customer = cur.fetchone()
        if customer is None:
            raise NotFound("customer not found")
        if customer["status"] != "ACTIVE":
            raise Forbidden("customer is not active")
        cur.execute(
            "SELECT customer_id FROM account.account_holders WHERE account_id = %s AND removed_at IS NULL",
            (account_id,),
        )
        current = [r["customer_id"] for r in cur.fetchall()]
        if customer_id in current:
            raise Conflict("customer is already a holder")
        if len(current) >= MAX_HOLDERS:
            raise Conflict(f"an account can have at most {MAX_HOLDERS} holders")
        cur.execute(
            """
            INSERT INTO account.account_holders (account_id, customer_id, role) VALUES (%s, %s, 'JOINT')
            ON CONFLICT (account_id, customer_id) DO UPDATE
                SET removed_at = NULL, added_at = now(), role = 'JOINT'
            """,
            (account_id, customer_id),
        )
        if account["operating_mode"] == "SINGLE":
            cur.execute(
                "UPDATE account.accounts SET operating_mode = 'EITHER_OR_SURVIVOR' WHERE account_id = %s",
                (account_id,),
            )
        _record_event(cur, account_id, "HOLDER_ADDED", {"customer_id": str(customer_id)}, actor)
    return get_account(conn, account_id)


def freeze_account(conn: psycopg.Connection, ledger: LedgerClient, account_id: UUID, *,
                   reason: str, actor: str) -> dict:
    ledger.set_status(account_id, "DEBIT_BLOCKED")  # block money first
    with conn.transaction(), _cur(conn) as cur:
        cur.execute("SELECT status FROM account.accounts WHERE account_id = %s FOR UPDATE", (account_id,))
        row = cur.fetchone()
        if row is None:
            raise NotFound("account not found")
        if row["status"] == "CLOSED":
            raise Conflict("account is closed")
        if row["status"] != "FROZEN":
            cur.execute(
                "UPDATE account.accounts SET status = 'FROZEN', freeze_reason = %s WHERE account_id = %s",
                (reason, account_id),
            )
            _record_event(cur, account_id, "ACCOUNT_FROZEN", {"reason": reason}, actor)
    return get_account(conn, account_id)


def unfreeze_account(conn: psycopg.Connection, ledger: LedgerClient, account_id: UUID, *, actor: str) -> dict:
    with conn.transaction(), _cur(conn) as cur:
        cur.execute("SELECT status FROM account.accounts WHERE account_id = %s FOR UPDATE", (account_id,))
        row = cur.fetchone()
        if row is None:
            raise NotFound("account not found")
        if row["status"] != "FROZEN":
            raise Conflict("account is not frozen")
        cur.execute(
            "UPDATE account.accounts SET status = 'ACTIVE', freeze_reason = NULL WHERE account_id = %s",
            (account_id,),
        )
        _record_event(cur, account_id, "ACCOUNT_UNFROZEN", {}, actor)
    ledger.set_status(account_id, "OPEN")  # unblock money last
    return get_account(conn, account_id)


# ------------------------------------------------------------------- beneficiaries & aliases


def add_beneficiary(conn: psycopg.Connection, customer_id: UUID, *, payee_account_number: str,
                    nickname: str | None = None) -> dict:
    payee = lookup_by_number(conn, payee_account_number)
    cooling_until = datetime.now(timezone.utc) + BENEFICIARY_COOLING
    try:
        with conn.transaction(), _cur(conn) as cur:
            cur.execute(
                """
                INSERT INTO account.beneficiaries
                    (customer_id, payee_account_number, payee_name, nickname, cooling_until)
                VALUES (%s, %s, %s, %s, %s) RETURNING *
                """,
                (customer_id, payee_account_number, payee["display_name"], nickname, cooling_until),
            )
            return cur.fetchone()
    except psycopg.errors.UniqueViolation as e:
        raise Conflict("payee already saved") from e
    except psycopg.errors.ForeignKeyViolation as e:
        raise NotFound("customer not found") from e


def list_beneficiaries(conn: psycopg.Connection, customer_id: UUID) -> list[dict]:
    with _cur(conn) as cur:
        cur.execute(
            """
            SELECT *, cooling_until > now() AS in_cooling_period
            FROM account.beneficiaries WHERE customer_id = %s AND removed_at IS NULL
            ORDER BY created_at
            """,
            (customer_id,),
        )
        return cur.fetchall()


def remove_beneficiary(conn: psycopg.Connection, customer_id: UUID, beneficiary_id: UUID) -> None:
    with _cur(conn) as cur:
        cur.execute("UPDATE account.beneficiaries SET removed_at = now() "
                    "WHERE beneficiary_id = %s AND customer_id = %s AND removed_at IS NULL RETURNING 1",
                    (beneficiary_id, customer_id))
        if cur.fetchone() is None:
            raise NotFound("payee not found")


def update_contact(conn: psycopg.Connection, customer_id: UUID, *, email: str | None = None,
                   phone: str | None = None) -> dict:
    """Called by Identity once the customer has confirmed the change with a code."""
    try:
        with conn.transaction(), _cur(conn) as cur:
            cur.execute(
                "UPDATE account.customers SET email = COALESCE(%s, email), phone = COALESCE(%s, phone) "
                "WHERE customer_id = %s RETURNING *",
                (email.strip().lower() if email else None, phone, customer_id))
            row = cur.fetchone()
    except psycopg.errors.UniqueViolation as e:
        raise Conflict("another customer already uses that email or phone") from e
    except psycopg.errors.CheckViolation as e:
        raise AccountError("invalid email or phone") from e
    if row is None:
        raise NotFound("customer not found")
    return _public_customer(row)


# ------------------------------------------------------------------- nominees
# Who receives the money if the holder dies. Up to four per account (FD and RD accounts
# included), shares adding up to at most 100%. A minor needs a guardian.


def list_nominees(conn: psycopg.Connection, account_id: UUID) -> list[dict]:
    with _cur(conn) as cur:
        cur.execute(
            "SELECT nominee_id, full_name, relation, date_of_birth, guardian_name, share_pct, created_at "
            "FROM account.nominees WHERE account_id = %s AND removed_at IS NULL ORDER BY created_at",
            (account_id,))
        return cur.fetchall()


def add_nominee(conn: psycopg.Connection, account_id: UUID, *, full_name: str, relation: str,
                date_of_birth: date | None, share_pct: float, guardian_name: str | None, actor: str) -> dict:
    relation = relation.upper()
    if relation not in NOMINEE_RELATIONS:
        raise AccountError(f"relation must be one of {', '.join(NOMINEE_RELATIONS)}")
    if len(full_name.strip()) < 2:
        raise AccountError("enter the nominee's full name")
    if date_of_birth is not None:
        today = date.today()
        if date_of_birth > today:
            raise AccountError("date of birth is in the future")
        age = today.year - date_of_birth.year - ((today.month, today.day) < (date_of_birth.month, date_of_birth.day))
        if age < 18 and not (guardian_name or "").strip():
            raise AccountError("a nominee under 18 needs a guardian")
    with conn.transaction(), _cur(conn) as cur:
        cur.execute("SELECT status FROM account.accounts WHERE account_id = %s FOR UPDATE", (account_id,))
        account = cur.fetchone()
        if account is None:
            raise NotFound("account not found")
        if account["status"] == "CLOSED":
            raise Conflict("account is closed")
        cur.execute("SELECT count(*) AS n, COALESCE(sum(share_pct), 0) AS total FROM account.nominees "
                    "WHERE account_id = %s AND removed_at IS NULL", (account_id,))
        current = cur.fetchone()
        if current["n"] >= MAX_NOMINEES:
            raise Conflict(f"an account can have at most {MAX_NOMINEES} nominees")
        if float(current["total"]) + share_pct > 100:
            raise AccountError(f"shares would add up to more than 100% "
                               f"({float(current['total']):g}% is already given)")
        cur.execute(
            """
            INSERT INTO account.nominees
                (account_id, full_name, relation, date_of_birth, share_pct, guardian_name, added_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            RETURNING nominee_id, full_name, relation, date_of_birth, guardian_name, share_pct, created_at
            """,
            (account_id, full_name.strip(), relation, date_of_birth, share_pct,
             (guardian_name or "").strip() or None, actor),
        )
        nominee = cur.fetchone()
        _record_event(cur, account_id, "NOMINEE_ADDED", {"nominee_id": str(nominee["nominee_id"]),
                                                         "relation": relation, "share_pct": share_pct}, actor)
    return nominee


def remove_nominee(conn: psycopg.Connection, account_id: UUID, nominee_id: UUID, actor: str) -> None:
    with conn.transaction(), _cur(conn) as cur:
        cur.execute("UPDATE account.nominees SET removed_at = now() "
                    "WHERE nominee_id = %s AND account_id = %s AND removed_at IS NULL RETURNING 1",
                    (nominee_id, account_id))
        if cur.fetchone() is None:
            raise NotFound("nominee not found")
        _record_event(cur, account_id, "NOMINEE_REMOVED", {"nominee_id": str(nominee_id)}, actor)


def create_alias(conn: psycopg.Connection, account_id: UUID, alias: str) -> dict:
    alias = alias.strip().lower()
    if not alias.endswith("@unbeatable"):
        alias = f"{alias}@unbeatable"
    try:
        with conn.transaction(), _cur(conn) as cur:
            cur.execute(
                "INSERT INTO account.aliases (alias, account_id) VALUES (%s, %s) RETURNING *",
                (alias, account_id),
            )
            return cur.fetchone()
    except psycopg.errors.UniqueViolation as e:
        raise Conflict("alias is taken, or this account already has an alias") from e
    except psycopg.errors.CheckViolation as e:
        raise AccountError("alias must be 3-31 characters: a-z, 0-9, dot, dash, underscore") from e
    except psycopg.errors.ForeignKeyViolation as e:
        raise NotFound("account not found") from e


def resolve_alias(conn: psycopg.Connection, alias: str) -> dict:
    with _cur(conn) as cur:
        cur.execute(
            "SELECT a.account_number FROM account.aliases al JOIN account.accounts a USING (account_id) "
            "WHERE al.alias = %s AND al.disabled_at IS NULL",
            (alias.strip().lower(),),
        )
        row = cur.fetchone()
    if row is None:
        raise NotFound("alias not found")
    return {**lookup_by_number(conn, row["account_number"]), "alias": alias.strip().lower(), "kind": "PAY_ID"}
